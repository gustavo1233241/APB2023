function mostra(frase){

    document.write(frase);
    document.write('<br>');
    
    
    
    }
    function resultado(){
   var resp = document.getElementById('resp');
    var num1 = parseFloat(document.getElementById('num1').value);
    var num2 = parseFloat(document.getElementById('num2').value);
    var texto = " ";
  
if(document.getElementById('multis').checked) texto = multi(num1 , num2);
if(document.getElementById('divisiv').checked) texto = divisi(num1 , num2);

if(document.getElementById('soma').checked) texto = soma(num1 , num2);
if(document.getElementById('sub').checked) texto = sub(num1 , num2);
   
   

resp.innerHTML = texto;
}


function multi( x , y){

    return(x * y);
}
     
function divisi( x , y){

    return(x / y);
}
function soma( x , y){

    return(x + y);
}
function sub( x , y){

    return(x - y);
}           

    


               

    
    
    
    
    
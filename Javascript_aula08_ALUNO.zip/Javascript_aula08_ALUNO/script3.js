var nome;
function guardar(){
    nome = document.getElementById("nome").value;
    alert("seu nome é: " + nome);

    document.getElementById("CU").style.display = 'none';
    document.getElementById("cupelo").style.display = 'block';
}

var idade;

function exibir(){

 idade = document.getElementById("idade").value; 
alert("seu nome é: " + nome + " e você tem " + idade + " anos");




}
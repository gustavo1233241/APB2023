function gu (){
    alert("Ola Mundo")
}
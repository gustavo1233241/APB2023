var idade1 = 18;
document.write(idade1, "+" );

var idade2 = 48;
document.write(idade2, "=" );

result = idade1 + idade2;


 var result;
 document.write(result);
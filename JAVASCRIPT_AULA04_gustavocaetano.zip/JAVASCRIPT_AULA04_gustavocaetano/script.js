var idade = 18;
document.write(idade);
var nome = "Ola mundo";
document.write(nome);
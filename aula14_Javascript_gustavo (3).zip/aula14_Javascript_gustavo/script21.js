
var respostas_positivas = 0;

var telefonou_vitima = prompt("Telefonou para a vítima? (sim/não)");

if (telefonou_vitima === "sim") {
    respostas_positivas++;
}

var esteve_local_crime = prompt("Esteve no local do crime? (sim/não)");

if (esteve_local_crime === "sim") {
    respostas_positivas++;
}

var mora_perto_vitima = prompt("Mora perto da vítima? (sim/não)");
if (mora_perto_vitima === "sim") {
    respostas_positivas++;
}

var devia_vitima = prompt("Devia para a vítima? (sim/não)");
if (devia_vitima === "sim") {
    respostas_positivas++;
}

var trabalhou_vitima = prompt("Já trabalhou com a vítima? (sim/não)");
if (trabalhou_vitima === "sim") {
    respostas_positivas++;
}

if (respostas_positivas === 2) {
    alert("Suspeita");
} else if (respostas_positivas >= 3 && respostas_positivas <= 4) {
    alert("Cúmplice");
} else if (respostas_positivas === 5) {
    alert("Assassino");
} else {
    alert("Inocente");
}

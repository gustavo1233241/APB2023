var morango = parseInt(prompt("Quantos quilos de morango você deseja comprar?"));
var maca = parseInt(prompt("Quantos quilos de maçã você deseja comprar?"));

var preco_morango;
if (morango <= 5) {
    preco_morango = 24.00;
} else {
    preco_morango = 20.00;
}

var preco_maca;
if (maca <= 5) {
    preco_maca = 8.80;
} else {
    preco_maca = 6.60;
}

var valor_total = (morango * preco_morango) + (maca * preco_maca);
if (morango + maca > 8 || valor_total > 224.00) {
    valor_total *= 0.9;
}

alert(`O valor total a ser pago é R$ ${valor_total.toFixed(2)}.`);

var num1 = parseInt(prompt("Digite um número inteiro:"));
 
 
 
  if ( num1 % 2 == 0) {
    alert("O número é par !");
  } else {
    alert("O número é ímpar.");
  }
  
var num = prompt("Digite um número inteiro menor que 1000:");

if (num >= 1 && num < 1000) {
 
    
    var centenas = num / 100;
    var dezenas = num % 100 / 10;
    var unidades = num % 10;

    

    var resultado = num + " = ";

    if (centenas > 0) {
        resultado += centenas + " centena" + (centenas > 1 ? "s" : "");
        if (dezenas > 0 || unidades > 0) {
            resultado += ", ";
        }
    }

    
        }
    

if (dezenas > 0) {
        resultado += dezenas + " dezenas" + (dezenas > 1 ? "s" : "");
        if (unidades > 0) {
            resultado += " e ";
        }
    }

    
        
    
   
if (unidades > 0) {
        resultado += unidades + " unidade" + (unidades > 1 ? "s" : "");
    }


    alert(resultado);


if(num >1000 && num < 1){
    
    alert("O número deve ser maior ou igual a 1 e menor que 1000.");
}
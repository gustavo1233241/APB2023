function verificavogal() {
    var letra = document.getElementById("vogais").value.toLowerCase();
    if (letra.length !== 1) {
        alert("Por favor, digite apenas uma letra.");
        return;
    }
    if (letra === "a" || letra === "e" || letra === "i" || letra === "o" || letra === "u") {
        alert("A letra digitada é uma vogal.");
    } else {
        alert("A letra digitada é uma consoante.");
    }
}
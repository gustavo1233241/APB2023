
var salario = parseInt(prompt('Qual é o seu salário: '));
var result1 = 0;
var result2 = 0;
var result3 = 0;
var result4 = 0;


result1 = salario * 0.2;

if(salario <= 1280){
    alert('Antes: ' + salario);
    alert('20% a mais');
    alert('Valor de aumento: ' + result1);
    alert('Depois: ' + (salario + result1));
}

result2 = salario * 0.15;

if(salario > 1280 && salario < 1700){
    alert('Antes: ' + salario);
    alert('15% a mais');
    alert('Valor de aumento: ' + result2);
    alert('Depois: ' + (salario + result2));
}

result3 = salario * 0.1;

if(salario > 1700 && salario < 2500){
    alert('Antes: ' + salario);
    alert('10% a mais');
    alert('Valor de aumento: ' + result3);
    alert('Depois: ' + (salario + result3));
}


result4 = salario * 0.05


if(salario >2500){
    alert('Antes: ' + salario);
    alert('5% a mais');
    alert('Valor de aumento: ' + result4);
    alert('Depois: ' + (salario + result4));
}





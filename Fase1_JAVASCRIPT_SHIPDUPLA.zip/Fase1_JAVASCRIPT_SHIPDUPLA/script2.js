var Fahrenheit = prompt("Informe uma temperatura em graus fahrenheit: ");
        Fahrenheit = parseInt(Fahrenheit);

        var convse = parseInt((Fahrenheit - 32) * 5/9);
        
        document.write("A temperatura Fahrenheit que você informou, quando convertida para a escala Celsius vale: : ", convse , " C");
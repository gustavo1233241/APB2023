var cels = prompt("Informe uma temperatura em graus Celsius: ");
        cels = parseInt(cels);

        var convse = parseInt(cels * 1.8 + 32);
        
        document.write("A temperatura Celsius que você informou, quando convertida para a escala Fahrenheit vale: ", convse , " F");
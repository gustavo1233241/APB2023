            var num1 = prompt("informe o raio de um círculo");
        
            num1 = parseInt(num1);
        
            var comprimento = parseInt(2 * Math.PI * num1 );
    
        var area = parseInt(Math.pow(Math.PI * num1 , 2));

 

document.write("O comprimento do círculo é: ", comprimento, " e a área do círculo é: ", area );

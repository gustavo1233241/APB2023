function drag(){

var num1 = parseFloat(document.getElementById('n1').value);
var resp = document.getElementById('resp');
var texto = " ";

if(document.getElementById('fih').checked) texto = feih(num1)
if(document.getElementById('celsius').checked) texto = cel(num1)



resp.innerHTML = texto;


}
function feih(x){
return ((x - 32) / 1.8)

}
function cel(x){
    return ((x *1.8) + 32)
    
    }





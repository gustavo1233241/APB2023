function idade1(){

    idade = document.getElementById("idades").value

    if (idade >= 65){

        alert("já pode se aposentar ");
    }
 else if (idade < 65){

alert(tempo, "Ate se aposentar");
var tempo = 65 - idade;
 

}
}




var idade;


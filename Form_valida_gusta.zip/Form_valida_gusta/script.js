const form = document.querySelector("#form");

const nameinput = document.querySelector("#name");

const emailinput = document.querySelector("#email");

const passawordinput = document.querySelector("#password");

const jobselect = document.querySelector("#job");

const mensagetextearea = document.querySelector("#mensage")

form.addEventListener("submit" , (event) =>{
    event.preventDefault()

if(nameinput.value === ""){

    alert("por favor preencha seu nome")
    return;
}
if(emailinput.value === "" || Isemailvalid(emailinput)){

    alert("por favor preencha seu email")
    return;
}
if(!validadepassaword(passawordinput.value,8)){

    alert("a senha precisa ter no minimo 8 caracteres")

}

if(jobselect.value === ""){

    alert("selecione uma opção")
}

if(mensagetextearea.value === ""){

alert("por favor, escreva uma mensagem")

}
 form.submit();
})

function Isemailvalid(email){

    const emailRegex = new RegExp(

        /^[a-zA-Z0-9, _ -]+@[a - z A - Z 0 - 9 ]+\.[a - z A - Z , _ . ]{2,}$/
    );

    if(emailRegex.test(email)){

        return true;
 
    }

    return false;
}

function validadepassaword(passaword, minDigits){

if (passaword.length>=minDigits){

return true;
}
return false;
}
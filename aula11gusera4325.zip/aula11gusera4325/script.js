


function verificanum (){
    
    var numb = document.getElementById("num1").value;


    if (numb > 0){
alert(numb + " é positivo");
}

else if (numb < 0){

    alert(numb + " é negativo");
}
if(numb == ""){
alert(" é nulo")
}


}



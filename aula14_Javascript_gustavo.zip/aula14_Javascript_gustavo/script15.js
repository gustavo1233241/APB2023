var dia = parseInt(prompt('Dia :'));
var mes = parseInt(prompt('Mes :'));
var ano = parseInt(prompt('Ano :'));




if (ano <= 2023){

alert(dia + '/' + mes + '/' + ano);


}
else{

    alert('data não valida');
}
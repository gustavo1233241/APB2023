var diafeira = parseInt(prompt("Digite o dia da semana: "));

switch(diafeira){

case 1: alert('Domingo');

break;

case 2: alert('Segunada');

break;

case 3: alert('Terça');

break;

case 4: alert('Quarta');

break;

case 5: alert('Quinta');

break;

case 6: alert('Sexta');

break;

case 7: alert('Sabado');




}

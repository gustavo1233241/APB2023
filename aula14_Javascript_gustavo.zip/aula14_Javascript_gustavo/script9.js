let valorHora = prompt("Qual é o valor da sua hora trabalhada?");
let horasTrabalhadas = prompt("Quantas horas você trabalhou neste mês?");

let salarioBruto = valorHora * horasTrabalhadas;
let fgts = salarioBruto * 0.11;
let sindicato = salarioBruto * 0.03;

let ir;
if (salarioBruto <= 2112) {
    ir = 0;
} else if (salarioBruto <= 2826.65) {
    ir = salarioBruto * 0.075 - 158.7;
} else if (salarioBruto <= 3751.05) {
    ir = salarioBruto * 0.15 - 354.8;
} else if (salarioBruto <= 4664.68) {
    ir = salarioBruto * 0.225 - 636.13;
} else {
    ir = salarioBruto * 0.275 - 869.36;
}

let inss = salarioBruto * 0.1;
let totalDescontos = ir + inss + sindicato;
let salarioLiquido = salarioBruto - totalDescontos;
alert(`Salário Bruto: R$ ${salarioBruto.toFixed(2)}`);
alert(`(-) IR (${ir.toFixed(2)}): R$ ${ir.toFixed(2)}`);
alert(`(-) INSS (${inss.toFixed(2)}): R$ ${inss.toFixed(2)}`);
alert(`FGTS (11%): R$ ${fgts.toFixed(2)}`);
alert(`(-) Sindicato (${sindicato.toFixed(2)}): R$ ${sindicato.toFixed(2)}`);
alert(`Total de descontos: R$ ${totalDescontos.toFixed(2)}`);
alert(`Salário Líquido: R$ ${salarioLiquido.toFixed(2)}`);

const nums = [1,5,3,10,4,6];

const maior = nums.reduce(function(prev, current) { 
	return prev > current ? prev : current; 
});
alert(maior)
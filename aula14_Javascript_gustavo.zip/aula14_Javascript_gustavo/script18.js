var valor_saque = parseInt(prompt("Qual valor você deseja sacar? (mínimo de 10 reais e máximo de 900 reais) "));
if (valor_saque < 10 || valor_saque > 900) {
    alert("Valor inválido. O valor mínimo é de 10 reais e o máximo de 900 reais.");
} else {
   var notas_100 = Math.floor(valor_saque / 100);
   var notas_50 = Math.floor((valor_saque % 100) / 50);
   var notas_20 = Math.floor(((valor_saque % 100) % 50) / 20);
   var notas_10 = Math.floor((((valor_saque % 100) % 50) % 20) / 10);

    alert('Para sacar a quantia de ' + valor_saque + ' reais, o script fornece ${notas_100} notas de 100, ${notas_50} nota(s) de 50, ${notas_20} nota(s) de 20 e ${notas_10} nota(s) de 10.');
}

let tipo_combustivel = prompt("Qual o tipo de combustível? (A-álcool, G-gasolina)");
let litros_vendidos = parseInt(prompt("Quantos litros foram vendidos?"));

var preco_litro;
if (tipo_combustivel == "A") {
    preco_litro = 4.88;
} else if (tipo_combustivel == "G") {
    preco_litro = 5.98;
} else {
    alert("Tipo de combustível inválido.");
}

var valor_total;
if (litros_vendidos <= 20) {
    valor_total = litros_vendidos * preco_litro;
} else {
    if (tipo_combustivel == "A") {
        valor_total = (20 * preco_litro) + ((litros_vendidos - 20) * (preco_litro * 0.97));
    } else if (tipo_combustivel == "G") {
        valor_total = (20 * preco_litro) + ((litros_vendidos - 20) * (preco_litro * 0.94));
    }
}

alert('O valor total a ser pago é R$ '+ valor_total + '.');

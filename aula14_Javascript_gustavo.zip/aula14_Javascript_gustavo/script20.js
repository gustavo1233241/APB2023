var num1 = parseFloat(prompt("Digite o primeiro número: "));
var num2 = parseFloat(prompt("Digite o segundo número: "));
var operacao = prompt("Qual operação você deseja realizar? (+, -, *, /)");

var resultado;
switch (operacao) {
    case "+":
        resultado = num1 + num2;
        break;
    case "-":
        resultado = num1 - num2;
        break;
    case "*":
        resultado = num1 * num2;
        break;
    case "/":
        resultado = num1 / num2;
        break;
    default:
        alert("Operação inválida.");
}

if (resultado !== undefined) {
    alert('O resultado da operação é ' + resultado + '.');
    if (resultado % 2 === 0) {
        alert("O número é par.");
    } else {
        alert("O número é ímpar.");
    }
    if (resultado > 0) {
        alert("O número é positivo.");
    } else if (resultado < 0) {
        alert("O número é negativo.");
    } else {
        alert("O número é zero.");
    }
    if (Math.round(resultado) === resultado) {
        alert("O número é inteiro.");
    } else {
        alert("O número é decimal.");
    }
}
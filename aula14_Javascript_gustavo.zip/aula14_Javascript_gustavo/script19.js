var numero = parseInt(prompt("Digite um número: "));
if (Math.round(numero) === numero) {
    alert('O número '+ numero + ' é inteiro.');
} else {
    alert('O número ' + numero + ' é decimal.');
}

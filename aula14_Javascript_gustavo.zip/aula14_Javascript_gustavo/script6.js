var num1 = prompt('1 numero');

var num2 = prompt('2 numero');

var num3 = prompt('3 numero');


if(num1 >= num2 && num1 >= num3 && num2 > num3){

    alert(num1 + " " + num2 + " "  + " " + num3)
}

if(num1 >= num2 && num1 >= num3 && num3 > num2){

    alert(num1 + " " + num2 + " "  + " " + num3)
}


if(num2 >= num1 && num2 >= num3 && num1 > num3){

    alert(num2 + " " + num1 + " "  + " " + num3)
}

if(num2 >= num1 && num2 >= num3 && num3 > num1){

    alert(num2 + " " + num1 + " "  + " " + num3)
}


if(num3 >= num1 && num3 >= num2 && num2 > num1){

    alert(num3 + " " + num2 + " "  + " " + num1)
}
if(num3 >= num1 && num3 >= num2 && num1 > num2){

    alert(num3 + " " + num3 + " "  + " " + num2)

}


if(num3 == num1 && num3 == num2 && num1 == num2){

    alert(num3 + " " + num3 + " "  + " " + num2)
}
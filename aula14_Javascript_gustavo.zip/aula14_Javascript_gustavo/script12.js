var a = parseInt(prompt("Digite o valor do primeiro lado: "));
var b = parseInt(prompt("Digite o valor do segundo lado: "));
var c = parseInt(prompt("Digite o valor do terceiro lado: "));

if (a + b > c && a + c > b && b + c > a) {
   
    if (a == b && b == c) {
        alert("Os valores formam um triângulo equilátero.");
    } 
    
    else if (a == b || a == c || b == c) {
        alert("Os valores formam um triângulo isósceles.");
    }
    
    
    else if (a != b && b != c && c != a ){
        alert("Os valores formam um triângulo escaleno.");
    }
} else {
    alert("Os valores não podem formar um triângulo.");
}

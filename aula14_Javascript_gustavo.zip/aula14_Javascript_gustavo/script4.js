var a = parseInt(prompt("Digite o primeiro número:"));
var b = parseInt(prompt("Digite o segundo número:"));

alert("Antes da troca: a = " + a + ", b = " + b);

var troca = a;
a = b;
b = troca;

alert("Depois da troca: a = " + a + ", b = " + b)

var num1 = parseInt(prompt("Digite o primeiro número: "));
        var num2 = parseInt(prompt("Digite o segundo número: "));
        var num3 = parseInt(prompt("Digite o terceiro número: "));

        if (num1 > num2 && num1 > num3) {
            alert("O maior número é " + num1);
        }
        
        
        else if (num2 > num1 && num2 > num3) {
            alert("O maior número é " + num2);
        } 
        
        
        else {
            alert("O maior número é " + num3);
        }
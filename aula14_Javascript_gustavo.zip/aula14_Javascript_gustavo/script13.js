const a = parseFloat(prompt("Digite o valor de a: "));
const b = parseFloat(prompt("Digite o valor de b: "));
const c = parseFloat(prompt("Digite o valor de c: "));

const delta = b ** 2 - 4 * a * c;

if (delta < 0) {
    console.log("A equação não possui raízes reais.");
} else if (delta === 0) {
    const x = -b / (2 * a);
    console.log(`A equação possui uma raiz real: x = ${x}.`);
} else {
    const x1 = (-b + ((b > 0 ? 1 : -1) * Math.sqrt(delta))) / (2 * a);
    const x2 = (-b - ((b > 0 ? 1 : -1) * Math.sqrt(delta))) / (2 * a);
    console.log(`A equação possui duas raízes reais: x1 = ${x1} e x2 = ${x2}.`);
}

function calculaPA(){

    var termo1 = parseInt(document.getElementById('t1').value);
    
    var termo2= parseInt(document.getElementById('t2').value);
    
    var termo3 = parseInt(document.getElementById('t3').value);
    
    
    
    
    var razao = parseInt(termo2) - parseInt(termo1) || parseInt(termo3) - parseInt(termo2);
    
    var n = document.getElementById("an").value;
    
    var result = termo1 + (n - 1) * razao
    
    if(razao === termo2 - termo1 || termo3 - termo2){
    
       
        
        document.write("an : ", result , ' razão: ', razao);
        
    
    }
  
    
    
    }
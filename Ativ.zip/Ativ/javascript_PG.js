function mostra(frase){

    document.write(frase);
    document.write('<br>');
}
function CalculaPG(){
var termo1 = parseInt(document.getElementById('t1').value);

var termo2 = parseInt(document.getElementById('t2').value);

var termo3 = parseInt(document.getElementById('t3').value);

var n = parseInt(document.getElementById('an').value);


var razao = termo2 / termo1 || termo2 / termo3;

var result = termo1 * Math.pow(razao, n - 1);





if(termo2 / termo1 === termo3 / termo2){

    document.write('É PA - ' + razao,' ', result);
}

else{

    alert('Não é PA')
}



                         


}
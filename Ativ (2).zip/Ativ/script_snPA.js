function calculaPG(){

    var termo1s = parseInt(document.getElementById('t1s').value);
    
    var termo2s= parseInt(document.getElementById('t2s').value);
    
    var termo3s = parseInt(document.getElementById('t3s').value);
    
    
    var razao = parseInt(termo2s) - parseInt(termo1s) || parseInt(termo3s) - parseInt(termo2s);
    
    var an = document.getElementById("Sn").value;
    
    var resultsm = (termo1s + resultsm) * an / 2;
    
    if(razao === termo2s - termo1s || termo3s - termo2s){
    
       
        console.log(termo1s + resultsm)
        document.write("sn : ", resultsm , ' razão: ', razao);
        
    
    }
  
    
    
    }



    
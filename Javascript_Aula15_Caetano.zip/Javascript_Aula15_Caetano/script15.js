function mostra(frase) {
    document.write(frase);
    document.write("<br>");
}

var contador = 2;
while (contador <= 100) {
    mostra("Número: " + contador);
    contador = contador + 2;
}


function mostra(frase){

    document.write(frase);
    document.write('<br>');
}

var termo1 = prompt('Coloque o 1 termo: ');
termo1 = parseInt(termo1);


var termo2 = prompt('Coloque o 2 termo: ');
termo2 = parseInt(termo2);



var termo3 = prompt('Coloque o 3 termo: ');
termo3 = parseInt(termo3);

var razao = termo2 - termo1 || termo2 - termo3;

if(termo2 - termo1 === termo3 - termo2){

    alert('É PA - ' + razao);
}

else{

    alert('Não é PA')
}

var n = prompt('Quala posição do numero na PA: ');
n = parseInt(n);

 var result = termo1 + (n - 1) * razao
                         
alert(result);
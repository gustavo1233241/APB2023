
function verificapika (){
    
    var meses = parseInt(document.getElementById('mes').value);
    
    if (meses >= 1 && meses <= 12) {
    

    
    
    switch (meses){
     case 1: alert('Janeiro');
     break;
    
     case 2: alert('Fevereiro');
     break;
    
     case 3: alert('MarÇo');
     break;
    
     case 4: alert('Abril');
     break;
    
     case 5: alert('Maio');
     break;
    
     case 6: alert('Junho');
     break;
    
     case 7: alert('Julho');
     break;
    
     case 8: alert('Agosto');
     break;
    
     case 9: alert('Setembro');
     break;
    
     case 10: alert('Outubro');
     
     break;
    
     case 11: alert('Novembro');
     
     break;
     
     case 12: alert('Desembro');
    
    break;
    }
    
    }
   
else{

    alert('num invalido, coloque um num entre 1 a 12')
}
}
   
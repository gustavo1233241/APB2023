


function igual (){
    var num1 = document.getElementById("iguais").value;
    var num2 = document.getElementById("igual6").value;
    if (num1 == num2){

        alert("true");
    }
else if(num1 != num2){

    alert('false')
}

}
function dif (){
    var num3 = document.getElementById("igual1").value;
    var num4 = document.getElementById("igual7").value;
    if (num3 != num4){

        alert("true");
    }
else if(num3 == num4){

    alert('false')
}

}
function maior (){
    var num5 = document.getElementById("igual2").value;
    var num6 = document.getElementById("igual8").value;
    if (num5 > num6){

        alert("true");
    }
else if(num5 < num6){

    alert('false')
}
}
function iguma (){
    var num7 = document.getElementById("igual3").value;
    var num8 = document.getElementById("igual9").value;
   
    if (num7 >= num8){

        alert("true");
    }
else if(num7 <= num8){

    alert('false')
}
}
function menor (){
    var num9 = document.getElementById("igual4").value;
    var num10 = document.getElementById("igual10").value;
   
    if (num9 < num10){

        alert("true");
    }
else if(num9 > num10){

    alert('false')
} 
}
function igume (){
    var num11 = document.getElementById("igual5").value;
    var num12 = document.getElementById("igual11").value;
   
    if (num11 <= num12){

        alert("true");
    }
else if(num11 >= num12){

    alert('false')
}   
}

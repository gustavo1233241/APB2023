function gu (){
    alert("Ola Mundo");
}
function daw (){
    document.getElementById("data").innerHTML = Date()
}
function mostra(frase){

    document.write(frase);
    document.write('<br>');
    
    
    
    }
    
    var contador1 = parseInt(prompt('Qual tabuada?'));
  

        for(var i = 0; i <= 10; i++){
           
               
    var result = contador1 * i
            mostra(contador1 +' x '+ i + ' = ' + result);
        }
    
    
    
    
    
function mostra(frase){

document.write(frase);
document.write('<br>');
}

    var contador = 3


    while (contador <= 100){

mostra('Numero: ' + contador);

contador = contador + 3

    }



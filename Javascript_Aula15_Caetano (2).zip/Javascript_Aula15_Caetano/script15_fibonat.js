var termo = parseInt(prompt('qual o termo'));


var num = [1, 1];

for (var i = 1; i <= termo - 2; i++){

num.push(num[i - 1] + num[i])


}

if (termo === 1 && termo === 2){

    document.write(termo)
}
document.write(num[termo - 1]);
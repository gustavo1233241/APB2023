function mostra(frase){

document.write(frase);
document.write('<br>');



}

var contador1 = -1;
var contador2 = 11;

    for(let i = 0; i <= 10; i++){
        contador1 = contador1 + 1;
        contador2 = contador2 - 1;
        mostra(contador1 + '-' + contador2);
    }






function verificavogal (){

    var vogal = ['a', 'o', 'i', 'u', 'e'];
var letra = document.getElementById('vogais').value;

for(let i = 0; i <  vogal.length; i++){
if (letra == vogal[i]){

    alert('É vogal');

}
}


}
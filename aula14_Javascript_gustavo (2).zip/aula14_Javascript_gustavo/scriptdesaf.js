var num1 = parseInt(prompt('Qual é o seu salario'));


var result = 0.925 * num1;
var porcent = result - num1




var result1 = 0.85 * num1 

var porcent1 = result1 - num1




var result2 = 0.775 * num1 

var porcent2 = result2 - num1





var result3 = num1 - (num1*0.275)

var porcent3 = result3 - num1



if( num1 < 2112){

alert('Não paga')

}

if( num1 > 2112 && num1 < 2826.65){

alert(result + " " + porcent);

}

if( num1 >= 2826.66 && num1 <= 3751.5){

alert(result1 +  '' + porcent1)
}


if( num1 >= 3751.6 && num1 <= 4664.67){

    alert(result2 + '' + porcent2)
    }



if(num1 >= 4664.68 ){

    alert(result3 + '' + porcent3)
}
    
 
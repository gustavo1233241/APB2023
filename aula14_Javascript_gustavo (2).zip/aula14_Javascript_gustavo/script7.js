var horario = prompt('Qual é o seu turno ?(M-matutino ou V-Vespertino ou N- Noturno.)') 


if (horario == 'M'){

alert('Bom Dia !!')

}


if (horario == 'V'){

    alert('Bom tarde !!')
    
    }

    if (horario == 'N'){

        alert('Bom Noite !!')
        
        }
        if (horario == ''){

            alert('Invalido!!')
        }
        
    

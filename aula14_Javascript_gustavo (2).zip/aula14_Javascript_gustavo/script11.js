

var nota1 = parseInt(prompt('Primeira nota:'));
var nota2 = parseInt(prompt('Segunda nota:'));
alert(nota1);
alert(nota2);

var media = (nota1 + nota2) / 2;

alert(media);

if (media >= 9 && media <= 10){

alert('A aprovato')
}

if (media >= 7.5 && media < 9){

    alert('B aprovado')

}


if (media >= 6 && media < 7.5){

    alert('C aprovado')

}

if (media >= 4 && media < 6){

    alert('D reprovado')

}

if (media >= 0 && media < 4){

    alert('E reprovado')

}
function media(){

var nota1 = document.getElementById('notas1').value;

var nota2 = document.getElementById('notas2').value;

var medias = ((parseInt(nota1) + parseInt(nota2)) / 2);

console.log(medias)
if(medias >= 6){

    alert('Aprovado!!')

}
else {

    alert('burro')
}
}
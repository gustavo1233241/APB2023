var idade = prompt('Digete sua idade');
document.write("Sua idade ", idade)
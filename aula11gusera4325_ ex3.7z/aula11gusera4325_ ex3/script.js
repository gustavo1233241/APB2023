


function votos (){
    
    var idade = document.getElementById("voto").value;

    if (idade < 16){
alert("Você não pode votar");
}

else if (idade >=16 && idade < 65){

    alert("O voto é facultativo");
}



}


